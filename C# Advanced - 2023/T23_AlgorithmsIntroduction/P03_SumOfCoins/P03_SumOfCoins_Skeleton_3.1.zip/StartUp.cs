﻿namespace SumOfCoins
{
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main(string[] args)
        {

        }

        public static Dictionary<int, int> ChooseCoins(IList<int> coins, int targetSum)
        {
            return null;
        }
    }
}