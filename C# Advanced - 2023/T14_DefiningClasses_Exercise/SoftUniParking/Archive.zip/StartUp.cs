﻿namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person peter = new();

            peter.Name = "Peter";
            peter.Age = 20;
        }
    }
}
