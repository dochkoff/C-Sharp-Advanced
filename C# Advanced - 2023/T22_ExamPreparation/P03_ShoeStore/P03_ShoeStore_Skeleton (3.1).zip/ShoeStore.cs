﻿namespace ShoeStore
{
    public class ShoeStore
    {
    }
}
